interface Travelable
{
   public double toDistance(Travelable otherTravelable);
   public double toTime(Travelable otherTravelable);
}
